from .bits import Bits


class VS(Bits):
    __slots__ = ()
