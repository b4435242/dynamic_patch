from .macho import MachO

__all__ = ["MachO"]
