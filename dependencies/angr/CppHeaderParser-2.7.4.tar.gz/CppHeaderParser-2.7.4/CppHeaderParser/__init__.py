# CppHeaderParser package
# Author: Jashua Cloutier (contact via sourceforge username:senexcanis)

from .CppHeaderParser import *

#__all__ = ['CppHeaderParser']
